SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://sql12775784:2XV7IU1ZKY@sql12.freesqldatabase.com:3306/sql12775784'
SQLALCHEMY_TRACK_MODIFICATIONS = False

SECRET_KEY = 'your_secret_key'

